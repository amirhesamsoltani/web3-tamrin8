# Interactive Loose-Leaf Todo List

A Pen created on CodePen.io. Original URL: [https://codepen.io/IanWoodard/pen/eYyVzzq](https://codepen.io/IanWoodard/pen/eYyVzzq).

A loose leaf todo list that can be edited in browser and is responsive.